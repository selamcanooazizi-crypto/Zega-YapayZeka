package com.zega.ai.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.zega.ai.R
import com.zega.ai.ZegaViewModel
import com.zega.ai.data.ChatMessage
import kotlinx.coroutines.launch

@Composable
fun ZegaLogo(size: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.zega_logo),
        contentDescription = stringResource(R.string.logo_desc),
        modifier = modifier.size(size)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ZegaViewModel, onOpenSettings: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var text by rememberSaveable { mutableStateOf("") }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = cs.surface, drawerContentColor = cs.onSurface) {
                DrawerContent(
                    vm = vm,
                    onNew = {
                        vm.newChat()
                        scope.launch { drawerState.close() }
                    },
                    onSelect = { id ->
                        vm.selectChat(id)
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Scaffold(
            containerColor = cs.background,
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ZegaLogo(28.dp)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.app_name))
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = stringResource(R.string.menu))
                        }
                    },
                    actions = {
                        IconButton(onClick = { vm.newChat() }) {
                            Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.new_chat))
                        }
                        IconButton(onClick = onOpenSettings) {
                            Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.settings))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = cs.background,
                        titleContentColor = cs.onBackground,
                        navigationIconContentColor = cs.onBackground,
                        actionIconContentColor = cs.onBackground
                    )
                )
            },
            bottomBar = {
                InputBar(
                    text = text,
                    onTextChange = { text = it },
                    generating = vm.generating,
                    onSend = {
                        vm.send(text)
                        text = ""
                    },
                    onStop = { vm.stop() }
                )
            }
        ) { pad ->
            val msgs = vm.currentChat?.messages.orEmpty()
            Box(Modifier.padding(pad).fillMaxSize()) {
                if (msgs.isEmpty()) {
                    EmptyState()
                } else {
                    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
                    LaunchedEffect(msgs.size, msgs.lastOrNull()?.text?.length) {
                        if (msgs.isNotEmpty()) listState.scrollToItem(msgs.lastIndex)
                    }
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(msgs, key = { it.id }) { m -> Bubble(m) }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        ZegaLogo(88.dp)
        Spacer(Modifier.size(16.dp))
        Text(
            stringResource(R.string.empty_title),
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.size(8.dp))
        Text(
            stringResource(R.string.empty_sub),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun errorText(code: String): String = when (code) {
    "NO_MODEL" -> stringResource(R.string.err_no_model)
    "MODEL_FAILED" -> stringResource(R.string.err_model_failed)
    "ENGINE_MISSING" -> stringResource(R.string.err_engine_missing)
    "CONTEXT_TOO_LONG" -> stringResource(R.string.err_context_too_long)
    else -> stringResource(R.string.err_generic) +
        if (code.startsWith("ERROR:") && code.length > 6) ": " + code.removePrefix("ERROR:") else ""
}

@Composable
private fun Bubble(m: ChatMessage) {
    val cs = MaterialTheme.colorScheme
    val user = m.role == "user"
    val container = when {
        m.isError -> cs.errorContainer
        user -> cs.primary
        else -> cs.surface
    }
    val content = when {
        m.isError -> cs.onErrorContainer
        user -> cs.onPrimary
        else -> cs.onSurface
    }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (user) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = container,
            contentColor = content,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            SelectionContainer {
                Text(
                    text = if (m.isError) errorText(m.text) else m.text,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        }
    }
}

@Composable
private fun InputBar(
    text: String,
    onTextChange: (String) -> Unit,
    generating: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(cs.background)
            .navigationBarsPadding()
            .imePadding()
            .padding(8.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = onTextChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text(stringResource(R.string.type_message)) },
            maxLines = 6,
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = cs.primary,
                unfocusedBorderColor = cs.onBackground.copy(alpha = 0.25f),
                focusedTextColor = cs.onBackground,
                unfocusedTextColor = cs.onBackground,
                cursorColor = cs.primary
            )
        )
        Spacer(Modifier.width(8.dp))
        FilledIconButton(
            onClick = { if (generating) onStop() else onSend() },
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = cs.primary,
                contentColor = cs.onPrimary
            )
        ) {
            if (generating) {
                Icon(Icons.Filled.Stop, contentDescription = stringResource(R.string.stop))
            } else {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.send))
            }
        }
    }
}

@Composable
private fun ColumnScope.DrawerContent(vm: ZegaViewModel, onNew: () -> Unit, onSelect: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ZegaLogo(36.dp)
        Spacer(Modifier.width(12.dp))
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge)
    }
    NavigationDrawerItem(
        label = { Text(stringResource(R.string.new_chat)) },
        selected = false,
        onClick = onNew,
        icon = { Icon(Icons.Filled.Add, contentDescription = null) },
        modifier = Modifier.padding(horizontal = 12.dp),
        colors = NavigationDrawerItemDefaults.colors(
            unselectedContainerColor = Color.Transparent,
            unselectedTextColor = cs.onSurface,
            unselectedIconColor = cs.onSurface
        )
    )
    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = cs.outline)
    Text(
        stringResource(R.string.history),
        style = MaterialTheme.typography.labelLarge,
        color = cs.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
    )
    if (vm.chats.isEmpty()) {
        Text(
            stringResource(R.string.no_chats),
            color = cs.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
        )
    } else {
        LazyColumn(modifier = Modifier.weight(1f, fill = false)) {
            items(vm.chats, key = { it.id }) { chat ->
                NavigationDrawerItem(
                    label = { Text(chat.title, maxLines = 1) },
                    selected = chat.id == vm.currentId,
                    onClick = { onSelect(chat.id) },
                    badge = {
                        IconButton(onClick = { vm.deleteChat(chat.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.delete))
                        }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp),
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = cs.background,
                        unselectedContainerColor = Color.Transparent,
                        selectedTextColor = cs.onSurface,
                        unselectedTextColor = cs.onSurface
                    )
                )
            }
        }
    }
}
