// JNI bridge between ZegaAI (Kotlin) and llama.cpp.
//
// Kotlin side: com.zega.ai.ai.LlamaBridge
//   load(path, nCtx, nThreads): String?   -> null on success, error text otherwise
//   unload()
//   generate(roles, contents, maxNew, cb): String? -> null on success, error text otherwise
//   stop()
//
// Every entry point catches all C++ exceptions; nothing may propagate into ART.

#include <jni.h>

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <memory>
#include <mutex>
#include <random>
#include <string>
#include <vector>

#include "llama.h"

#ifdef __ANDROID__
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "ZegaLLM", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "ZegaLLM", __VA_ARGS__)
#else
#include <cstdio>
#define LOGI(...) do { fprintf(stderr, "[I] "); fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while (0)
#define LOGE(...) do { fprintf(stderr, "[E] "); fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while (0)
#endif

namespace {

struct Engine {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    uint32_t n_ctx = 0;
    uint32_t n_batch = 0;
    std::vector<llama_token> cached;  // tokens currently held in the KV cache (sequence 0)
};

std::mutex g_mutex;           // serialises load / unload / generate
Engine g_engine;
std::atomic<bool> g_stop{false};
std::string g_last_error;     // last error line printed by llama.cpp (for useful messages)
std::mutex g_log_mutex;

void log_cb(enum ggml_log_level level, const char *text, void *) {
    if (level == GGML_LOG_LEVEL_ERROR) {
        LOGE("%s", text);
        std::lock_guard<std::mutex> lk(g_log_mutex);
        g_last_error = text;
        while (!g_last_error.empty() && (g_last_error.back() == '\n' || g_last_error.back() == '\r')) {
            g_last_error.pop_back();
        }
    } else if (level == GGML_LOG_LEVEL_WARN) {
        LOGI("%s", text);
    }
}

std::string take_last_error() {
    std::lock_guard<std::mutex> lk(g_log_mutex);
    std::string s = g_last_error;
    g_last_error.clear();
    return s;
}

bool abort_cb(void *) { return g_stop.load(std::memory_order_relaxed); }

void free_engine_locked() {
    if (g_engine.ctx) llama_free(g_engine.ctx);
    if (g_engine.model) llama_model_free(g_engine.model);
    g_engine = Engine();
}

jstring make_jstring(JNIEnv *env, const std::string &s) {
    // Error strings can contain arbitrary bytes (file names...). Sanitise to ASCII/UTF-8 BMP only
    // so NewStringUTF (modified UTF-8) never sees an invalid sequence.
    std::string safe;
    safe.reserve(s.size());
    for (unsigned char c : s) {
        if (c < 0x80) safe.push_back((char) c);
        else safe.push_back('?');
    }
    return env->NewStringUTF(safe.c_str());
}

std::string jstr(JNIEnv *env, jstring js) {
    if (!js) return std::string();
    const char *c = env->GetStringUTFChars(js, nullptr);
    if (!c) return std::string();
    std::string s(c);
    env->ReleaseStringUTFChars(js, c);
    return s;
}

// Reads a Java String as real UTF-8 (JNI gives modified UTF-8, which differs for
// supplementary characters such as emoji and for U+0000). Goes through String.getBytes("UTF-8").
std::string jstr_utf8(JNIEnv *env, jstring js) {
    if (!js) return std::string();
    jclass sc = env->FindClass("java/lang/String");
    jmethodID gb = env->GetMethodID(sc, "getBytes", "(Ljava/lang/String;)[B");
    jstring enc = env->NewStringUTF("UTF-8");
    auto arr = (jbyteArray) env->CallObjectMethod(js, gb, enc);
    env->DeleteLocalRef(enc);
    env->DeleteLocalRef(sc);
    if (env->ExceptionCheck() || !arr) {
        env->ExceptionClear();
        return std::string();
    }
    jsize n = env->GetArrayLength(arr);
    std::string out((size_t) n, '\0');
    if (n > 0) env->GetByteArrayRegion(arr, 0, n, reinterpret_cast<jbyte *>(&out[0]));
    env->DeleteLocalRef(arr);
    return out;
}

// Length of the longest prefix of `s` that consists of complete UTF-8 sequences
// (a trailing incomplete sequence is held back until the next token completes it).
size_t utf8_complete_prefix(const std::string &s) {
    size_t n = s.size();
    if (n == 0) return 0;
    // Look back at most 3 bytes for the start of the last sequence.
    for (size_t back = 1; back <= std::min<size_t>(4, n); ++back) {
        unsigned char c = (unsigned char) s[n - back];
        if ((c & 0xC0) == 0x80) continue;  // continuation byte, keep looking
        size_t need = 1;
        if ((c & 0x80) == 0) need = 1;
        else if ((c & 0xE0) == 0xC0) need = 2;
        else if ((c & 0xF0) == 0xE0) need = 3;
        else if ((c & 0xF8) == 0xF0) need = 4;
        else return n;  // invalid lead byte: let Kotlin replace it
        return (back >= need) ? n : n - back;
    }
    return n;
}

struct Msg {
    std::string role;
    std::string content;
};

// Applies the model's own chat template; falls back to ChatML when the model has no
// template or llama.cpp does not recognise it.
std::string build_prompt(const llama_model *model, const std::vector<Msg> &msgs) {
    std::vector<llama_chat_message> chat;
    chat.reserve(msgs.size());
    for (const auto &m : msgs) chat.push_back({m.role.c_str(), m.content.c_str()});

    size_t total = 0;
    for (const auto &m : msgs) total += m.content.size() + m.role.size();

    auto apply = [&](const char *tmpl) -> std::string {
        std::vector<char> buf(std::max<size_t>(total * 2 + 1024, 4096));
        int32_t n = llama_chat_apply_template(tmpl, chat.data(), chat.size(), true, buf.data(), (int32_t) buf.size());
        if (n > (int32_t) buf.size()) {
            buf.resize((size_t) n + 16);
            n = llama_chat_apply_template(tmpl, chat.data(), chat.size(), true, buf.data(), (int32_t) buf.size());
        }
        if (n < 0) return std::string();
        return std::string(buf.data(), (size_t) n);
    };

    const char *own = llama_model_chat_template(model, nullptr);
    if (own) {
        std::string p = apply(own);
        if (!p.empty()) return p;
    }
    std::string p = apply("chatml");
    if (!p.empty()) return p;

    // Last resort: hand-written ChatML.
    std::string out;
    for (const auto &m : msgs) out += "<|im_start|>" + m.role + "\n" + m.content + "<|im_end|>\n";
    out += "<|im_start|>assistant\n";
    return out;
}

bool tokenize_prompt(const llama_vocab *vocab, const std::string &text, std::vector<llama_token> &out) {
    int32_t cap = (int32_t) text.size() + 16;
    out.resize((size_t) cap);
    int32_t n = llama_tokenize(vocab, text.c_str(), (int32_t) text.size(), out.data(), cap, true, true);
    if (n < 0) {
        if (n == INT32_MIN) return false;
        out.resize((size_t) -n);
        n = llama_tokenize(vocab, text.c_str(), (int32_t) text.size(), out.data(), -n, true, true);
        if (n < 0) return false;
    }
    out.resize((size_t) n);
    // Templates such as Gemma/Llama3 already contain the BOS text; avoid a doubled BOS.
    llama_token bos = llama_vocab_bos(vocab);
    if (bos != LLAMA_TOKEN_NULL && out.size() > 1 && out[0] == bos && out[1] == bos) out.erase(out.begin());
    return true;
}

// Runs llama_decode on [tokens, tokens+n) in chunks of at most n_batch tokens.
// returns 0 on success, otherwise the llama_decode error (2 == aborted)
int decode_tokens(llama_context *ctx, llama_token *tokens, size_t n, uint32_t n_batch) {
    size_t i = 0;
    while (i < n) {
        if (g_stop.load()) return 2;
        size_t c = std::min<size_t>(n_batch, n - i);
        llama_batch b = llama_batch_get_one(tokens + i, (int32_t) c);
        int rc = llama_decode(ctx, b);
        if (rc != 0) return rc;
        i += c;
    }
    return 0;
}

void reset_cache_locked() {
    if (g_engine.ctx) llama_memory_clear(llama_get_memory(g_engine.ctx), true);
    g_engine.cached.clear();
}

}  // namespace

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_zega_ai_ai_LlamaBridge_load(JNIEnv *env, jobject, jstring jpath, jint nCtx, jint nThreads) {
    try {
        std::string path = jstr(env, jpath);
        std::lock_guard<std::mutex> lk(g_mutex);
        free_engine_locked();
        g_stop = false;

        static bool inited = false;
        if (!inited) {
            llama_log_set(log_cb, nullptr);
            llama_backend_init();
            inited = true;
        }
        take_last_error();

        llama_model_params mp = llama_model_default_params();
        mp.n_gpu_layers = 0;
        mp.load_mode = LLAMA_LOAD_MODE_MMAP;
        llama_model *model = llama_model_load_from_file(path.c_str(), mp);
        if (!model) {
            std::string e = take_last_error();
            return make_jstring(env, e.empty() ? "llama_model_load_from_file failed" : e);
        }

        const int32_t train_ctx = llama_model_n_ctx_train(model);
        uint32_t n_ctx = (uint32_t) std::max(256, (int) nCtx);
        if (train_ctx > 0 && n_ctx > (uint32_t) train_ctx) n_ctx = (uint32_t) train_ctx;

        llama_context_params cp = llama_context_default_params();
        cp.n_ctx = n_ctx;
        cp.n_batch = std::min<uint32_t>(512, n_ctx);
        cp.n_ubatch = std::min<uint32_t>(256, cp.n_batch);
        cp.n_threads = std::max(1, (int) nThreads);
        cp.n_threads_batch = std::max(1, (int) nThreads);
        cp.abort_callback = abort_cb;
        cp.abort_callback_data = nullptr;

        llama_context *ctx = llama_init_from_model(model, cp);
        if (!ctx) {
            llama_model_free(model);
            std::string e = take_last_error();
            return make_jstring(env, e.empty() ? "llama_init_from_model failed (not enough memory?)" : e);
        }

        g_engine.model = model;
        g_engine.ctx = ctx;
        g_engine.vocab = llama_model_get_vocab(model);
        g_engine.n_ctx = llama_n_ctx(ctx);
        g_engine.n_batch = cp.n_batch;
        g_engine.cached.clear();
        LOGI("model loaded, n_ctx=%u threads=%d", g_engine.n_ctx, (int) nThreads);
        return nullptr;
    } catch (const std::exception &e) {
        return make_jstring(env, std::string("native exception: ") + e.what());
    } catch (...) {
        return make_jstring(env, "native exception");
    }
}

JNIEXPORT void JNICALL
Java_com_zega_ai_ai_LlamaBridge_unload(JNIEnv *, jobject) {
    try {
        g_stop = true;  // abort a running generation so we can take the lock quickly
        std::lock_guard<std::mutex> lk(g_mutex);
        free_engine_locked();
        g_stop = false;
    } catch (...) {
    }
}

JNIEXPORT void JNICALL
Java_com_zega_ai_ai_LlamaBridge_stop(JNIEnv *, jobject) {
    g_stop = true;
}

JNIEXPORT jstring JNICALL
Java_com_zega_ai_ai_LlamaBridge_generate(JNIEnv *env, jobject, jobjectArray jroles, jobjectArray jcontents,
                                         jint maxNew, jobject cb) {
    try {
        std::lock_guard<std::mutex> lk(g_mutex);
        g_stop = false;
        if (!g_engine.ctx || !g_engine.model) return make_jstring(env, "NO_MODEL");

        // ---- collect messages ----
        std::vector<Msg> msgs;
        jsize n = env->GetArrayLength(jroles);
        for (jsize i = 0; i < n; ++i) {
            auto r = (jstring) env->GetObjectArrayElement(jroles, i);
            auto c = (jstring) env->GetObjectArrayElement(jcontents, i);
            msgs.push_back({jstr(env, r), jstr_utf8(env, c)});
            env->DeleteLocalRef(r);
            env->DeleteLocalRef(c);
        }
        if (msgs.empty()) return make_jstring(env, "empty conversation");

        // ---- build + tokenize prompt, dropping the oldest turns until it fits ----
        const uint32_t n_ctx = g_engine.n_ctx;
        uint32_t reserve = (uint32_t) std::max(64, std::min((int) maxNew, (int) (n_ctx / 2)));
        std::vector<llama_token> tokens;
        for (;;) {
            std::string prompt = build_prompt(g_engine.model, msgs);
            if (!tokenize_prompt(g_engine.vocab, prompt, tokens)) return make_jstring(env, "tokenization failed");
            if (tokens.size() + reserve <= n_ctx) break;
            // find the oldest droppable message: keep a leading system message and the last message
            size_t first = (!msgs.empty() && msgs[0].role == "system") ? 1 : 0;
            if (msgs.size() <= first + 1) {
                return make_jstring(env, "CONTEXT_TOO_LONG");
            }
            msgs.erase(msgs.begin() + (long) first);
            // keep the conversation starting with a user turn after the system message
            while (msgs.size() > first + 1 && msgs[first].role != "user") msgs.erase(msgs.begin() + (long) first);
        }
        const int32_t max_new = (int32_t) std::min<size_t>((size_t) std::max(1, (int) maxNew), n_ctx - tokens.size());

        // ---- reuse the KV cache for the common prefix ----
        size_t common = 0;
        const size_t lim = std::min(g_engine.cached.size(), tokens.size());
        while (common < lim && g_engine.cached[common] == tokens[common]) ++common;
        if (common == tokens.size()) --common;  // always re-decode at least the last prompt token (need logits)
        if (common < g_engine.cached.size()) {
            llama_memory_t mem = llama_get_memory(g_engine.ctx);
            if (!llama_memory_seq_rm(mem, 0, (llama_pos) common, -1)) {
                reset_cache_locked();
                common = 0;
            }
            g_engine.cached.resize(common);
        }

        // ---- sampler ----
        llama_sampler_chain_params sp = llama_sampler_chain_default_params();
        llama_sampler *smpl = llama_sampler_chain_init(sp);
        llama_sampler_chain_add(smpl, llama_sampler_init_penalties(llama_vocab_n_tokens(g_engine.vocab), 64, 1.1f, 0.0f, 0.0f));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_min_p(0.05f, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.7f));
        std::random_device rd;
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(rd()));
        struct SamplerGuard {
            llama_sampler *s;
            ~SamplerGuard() { llama_sampler_free(s); }
        } guard{smpl};

        // ---- prompt processing ----
        std::vector<llama_token> todo(tokens.begin() + (long) common, tokens.end());
        int rc = decode_tokens(g_engine.ctx, todo.data(), todo.size(), g_engine.n_batch);
        if (rc != 0) {
            reset_cache_locked();
            if (rc == 2 && g_stop) return nullptr;  // user pressed stop while reading the prompt
            return make_jstring(env, "llama_decode failed (prompt), code " + std::to_string(rc));
        }
        g_engine.cached = tokens;
        for (llama_token t : tokens) llama_sampler_accept(smpl, t);

        // ---- callback plumbing ----
        jclass cbClass = env->GetObjectClass(cb);
        jmethodID onToken = env->GetMethodID(cbClass, "onToken", "([B)Z");
        env->DeleteLocalRef(cbClass);
        if (!onToken) {
            env->ExceptionClear();
            return make_jstring(env, "callback method not found");
        }
        auto emit = [&](const std::string &bytes) -> bool {
            if (bytes.empty()) return true;
            jbyteArray arr = env->NewByteArray((jsize) bytes.size());
            if (!arr) {
                env->ExceptionClear();
                return false;
            }
            env->SetByteArrayRegion(arr, 0, (jsize) bytes.size(), reinterpret_cast<const jbyte *>(bytes.data()));
            jboolean cont = env->CallBooleanMethod(cb, onToken, arr);
            env->DeleteLocalRef(arr);
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                return false;
            }
            return cont == JNI_TRUE;
        };

        // ---- generation loop ----
        std::string pending;
        char piece[256];
        bool keep_going = true;
        for (int32_t i = 0; i < max_new && keep_going; ++i) {
            if (g_stop) break;
            llama_token tok = llama_sampler_sample(smpl, g_engine.ctx, -1);
            if (llama_vocab_is_eog(g_engine.vocab, tok)) break;
            llama_sampler_accept(smpl, tok);

            int32_t len = llama_token_to_piece(g_engine.vocab, tok, piece, (int32_t) sizeof(piece), 0, false);
            if (len < 0) {
                std::vector<char> big((size_t) -len);
                len = llama_token_to_piece(g_engine.vocab, tok, big.data(), (int32_t) big.size(), 0, false);
                if (len > 0) pending.append(big.data(), (size_t) len);
            } else if (len > 0) {
                pending.append(piece, (size_t) len);
            }

            size_t ok = utf8_complete_prefix(pending);
            if (ok > 0) {
                keep_going = emit(pending.substr(0, ok));
                pending.erase(0, ok);
            }

            llama_token t1 = tok;
            int drc = decode_tokens(g_engine.ctx, &t1, 1, 1);
            if (drc != 0) {
                reset_cache_locked();
                if (drc == 2 && g_stop) return nullptr;
                return make_jstring(env, "llama_decode failed (generation), code " + std::to_string(drc));
            }
            g_engine.cached.push_back(tok);
        }
        if (!pending.empty()) emit(pending);
        return nullptr;
    } catch (const std::exception &e) {
        return make_jstring(env, std::string("native exception: ") + e.what());
    } catch (...) {
        return make_jstring(env, "native exception");
    }
}

}  // extern "C"
