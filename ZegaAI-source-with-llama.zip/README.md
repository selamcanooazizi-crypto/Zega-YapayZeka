# ZegaAİ — Aşama 1

Kotlin + Jetpack Compose ile yazılmış Android Studio projesi.

## Derleme (APK üretme)

1. Android Studio (Ladybug veya yeni) ile `ZegaAI` klasörünü açın. Gradle senkronizasyonunu bekleyin
   (Android SDK 35 ve internet gerekir; Android Studio eksik SDK'yı kendisi indirmeyi önerir).
2. Telefonu USB ile bağlayıp **Run** deyin; ya da menüden
   **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin.
3. APK şurada oluşur: `app/build/outputs/apk/debug/app-debug.apk`

> Not: Bu projede `gradlew` yoktur. Android Studio kendi Gradle'ını kullanır. Komut satırı için proje
> klasöründe bir kez `gradle wrapper --gradle-version 8.9` çalıştırın.

## Yerel yapay zekâ (GGUF / llama.cpp) — bu sürümde VAR

- `app/src/main/cpp/llama.cpp`: llama.cpp kaynağı, `llama_jni.cpp`: JNI köprüsü, `CMakeLists.txt`: arm64-v8a derlemesi
- `ai/LlamaBridge.kt` (JNI), `ai/LocalModelManager.kt` (GGUF seç → uygulama deposuna kopyala → yükle),
  `ai/LocalLlamaEngine.kt` (akışlı sohbet, Türkçe sistem istemi, durdurma)
- Ayarlar > Model yönetimi: "GGUF modeli seç", durum/ilerleme, yeniden dene, modeli kaldır
- Model yoksa sohbette açık uyarı gösterilir; model yüklendikten sonra internet gerekmez
- Sohbet geçmişi, tema, dil ayarları değişmedi
- Çökme koruması: model yüklemesi sırasında süreç ölürse model bir sonraki açılışta otomatik yüklenmez
- Hedef: arm64-v8a, Android 8.0+ (dotprod + fp16 olan işlemciler; olmayanlarda anlaşılır hata gösterilir)

Önerilen model: Türkçe için Qwen2.5 1.5B/3B Instruct veya Gemma 3 (Q4_K_M, .gguf).

## Derleme notları

- Gerekli: Android SDK 35, **NDK 27.0.12077973**, **CMake 3.22.1** (Android Studio SDK Manager > SDK Tools).
- Çıktılar: `assembleDebug` ve `assembleRelease` (ikisi de kurulabilir; release, kendi anahtarın yoksa debug anahtarıyla imzalanır).
  Kendi anahtarınla imzalamak için `ZEGA_KEYSTORE`, `ZEGA_KEYSTORE_PASSWORD`, `ZEGA_KEY_ALIAS`, `ZEGA_KEY_PASSWORD` ortam değişkenlerini verin.
- Yerel motorun bilgisayarda testi: `tools/native-test/README.md`

## Hâlâ YOK

- Bulut model, internet araması, dosya/fotoğraf/video yükleme ve inceleme, görsel/video üretimi, sesli sohbet

## Bilgisayarsız / bulutta derleme (GitHub Actions)

1. github.com'da ücretsiz hesap açın, yeni bir depo (repository) oluşturun.
2. Bu klasörün içeriğini depoya yükleyin (Add file > Upload files). `.github/workflows/build.yml` dosyasının da yüklendiğinden emin olun.
3. Depoda **Actions** sekmesine girin, **Build APK** iş akışının bitmesini bekleyin (birkaç dakika).
4. Biten çalıştırmayı açın, sayfanın altındaki **Artifacts** bölümünden **ZegaAI-apk** dosyasını indirin (ZIP içinde app-debug.apk ve app-release.apk). llama.cpp derlemesi nedeniyle ilk çalıştırma ~10-20 dakika sürebilir.
