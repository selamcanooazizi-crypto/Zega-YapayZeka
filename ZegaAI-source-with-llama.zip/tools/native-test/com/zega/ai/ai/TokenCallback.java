package com.zega.ai.ai;
public interface TokenCallback { boolean onToken(byte[] bytes); }
